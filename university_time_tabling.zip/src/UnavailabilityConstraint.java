public class UnavailabilityConstraint {
    public int day, period, course;
}
